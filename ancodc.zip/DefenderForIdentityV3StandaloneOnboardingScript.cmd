@@echo off
@@setlocal DisableDelayedExpansion
@@set "MDI_ONBOARDING_SCRIPT_PATH=%~f0"
@@set "ERRORLEVEL="
@@powershell -noprofile -command "$code = [System.IO.File]::ReadAllLines($env:MDI_ONBOARDING_SCRIPT_PATH) -notmatch '^@@'; & ([scriptblock]::Create($code -join [Environment]::NewLine))"
@@exit /b %errorlevel%


# *** POWERSHELL CODE STARTS HERE *** #
function Write-Log {
    param([Parameter(ValueFromRemainingArguments = $true)]$Message)
    Microsoft.PowerShell.Utility\Write-Host -Object ($(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message)
}

function Test-Admin {
    try {
        $principal = New-Object Security.Principal.WindowsPrincipal -ArgumentList (
            [Security.Principal.WindowsIdentity]::GetCurrent())
        $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        $false
    }
}

function Get-MachineProductType {
    (Microsoft.PowerShell.Management\Get-WmiObject -Class Win32_OperatingSystem -Property ProductType -ErrorAction Stop).ProductType
}

function Get-MachineServices {
    Microsoft.PowerShell.Management\Get-Service -ErrorAction Stop
}

function Get-SupportedServerRole {
    $productType = Get-MachineProductType
    if ($productType -eq 2) {
        return 'Domain Controller'
    }
    if ($productType -ne 3) {
        return $null
    }

    $serviceNames = @((Get-MachineServices).Name)
    if ($serviceNames -contains 'adfssrv') {
        return 'AD FS'
    }
    if ($serviceNames -contains 'ADSync') {
        return 'Microsoft Entra Connect'
    }
    if ($serviceNames -contains 'CertSvc') {
        return 'AD CS'
    }
    return $null
}

function Test-ServerOS {
    $os = [System.Environment]::OSVersion.Version
    ($os.Major -ge 10 -and $os.Build -ge 17763)
}

function Test-ClassicMdiSensor {
    try {
        [bool](Microsoft.PowerShell.Management\Get-Service -Name 'AATPSensor' -ErrorAction Stop)
    } catch {
        $false
    }
}

function Test-SenseOnboarding {
    try {
        [bool](Microsoft.PowerShell.Management\Get-ItemProperty -Path 'registry::HKLM\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection' -Name 'OnboardingInfo' -ErrorAction Stop)
    } catch {
        $false
    }
}

function Test-SenseVersion {
    param([System.Version]$MinimumVersion = [System.Version]::New('10.8735.0.0'))
    $sensePath = Join-Path ${env:ProgramW6432} 'Windows Defender Advanced Threat Protection\MsSense.exe'

    if (Test-Path $sensePath) {
        $senseVersion = (Get-Item $sensePath).VersionInfo.ProductVersion
        return [System.Version]::New($senseVersion) -ge $MinimumVersion
    }
    Write-Log "Error - MSSense.exe is missing Aborting."
    exit(6)
    return $false
}

if (Test-Admin) {
    Write-Log "Info - Script is running with administrator privileges"
} else {
    Write-Log "Error - Script is not running with administrator privileges. Aborting."
    exit(1)
}

try {
    $serverRole = Get-SupportedServerRole
} catch {
    Write-Log "Error - Failed to determine the machine's identity role: $($_.Exception.Message). Aborting."
    exit(2)
}
if (-not $serverRole) {
    Write-Log "Error - Machine is not a Domain Controller, AD FS, AD CS certification authority, or Microsoft Entra Connect server. Aborting."
    exit(2)
}
Write-Log "Info - Machine is $serverRole"

if (Test-ServerOS) {
    Write-Log "Info - Operating System is Windows Server 2019 or above"
} else {
    Write-Log "Error - Operating System is not Windows Server 2019 or above. Aborting."
    exit(3)
}

if (-not (Test-ClassicMdiSensor)) {
    Write-Log "Info - Classic MDI Sensor is not installed"
} else {
    Write-Log "Error - Classic MDI Sensor is installed. Aborting."
    exit(4)
}

if (-not (Test-SenseOnboarding)) {
    Write-Log "Info - Machine is not onboarded to Sense"
} else {
    Write-Log "Error - Machine is already onboarded to Sense. Aborting."
    exit(5)
}

$minimumSenseVersion = [System.Version]::New('10.8735.0.0')
if ($serverRole -ne 'Domain Controller') {
    $minimumSenseVersion = [System.Version]::New('10.8830.0.0')
}
try {
    $senseVersionSupported = Test-SenseVersion -MinimumVersion $minimumSenseVersion
} catch {
    Write-Log "Error - Failed to read Sense version: $($_.Exception.Message). Aborting."
    exit(6)
}

if ($senseVersionSupported) {
    Write-Log "Info - Sense version is above $minimumSenseVersion."
} else {
    Write-Log "Error - Sense version is below the required $minimumSenseVersion. Aborting."
    exit(6)
}

Write-Log "Info - All pre-flight checks passed. Running onboarding package..."
$onboardingPackage = (Join-Path -Path $pwd.Path -ChildPath 'resources\_internalOnboarding.exe')

if (-not (Test-Path $onboardingPackage)) {
    Write-Log "Error - Onboarding package not found at $onboardingPackage. Aborting."
    exit(8)
}

$secureEncryptionKey = Microsoft.PowerShell.Utility\Read-Host -Prompt 'Enter the encryption key from the onboarding portal' -AsSecureString
if ($null -eq $secureEncryptionKey -or $secureEncryptionKey.Length -eq 0) {
    Write-Log "Error - No encryption key provided. Aborting."
    exit(9)
}

$encryptionKeyBstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureEncryptionKey)
try {
    $encryptionKey = [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($encryptionKeyBstr)
    & $onboardingPackage -Quiet "-key:$encryptionKey"
    $onboardingExitCode = $LASTEXITCODE
} finally {
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($encryptionKeyBstr)
    $encryptionKey = $null
}

if ($onboardingExitCode -ne 0) {
    Write-Log "Error - Onboarding package exited with code $onboardingExitCode. Aborting."
    exit($onboardingExitCode)
}

Write-Log "Info - Onboarding package completed successfully."
