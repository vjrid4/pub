@echo off

echo This script is for onboarding machines to the Microsoft Defender for Endpoint services, including security and compliance products.
echo Once completed, the machine should light up in the portal within 5-30 minutes, depending on this machine's Internet connectivity availability and machine power state (plugged in vs. battery powered).
echo IMPORTANT: This script is optimized for onboarding a single machine and should not be used for large scale deployment.
echo For more information on large scale deployment, please consult the MDE documentation (links available in the MDE portal under the endpoint onboarding section).
echo.
:USER_CONSENT
set /p shouldContinue= "Press (Y) to confirm and continue or (N) to cancel and exit: "
IF /I "%shouldContinue%"=="N" (
	GOTO CLEANUP
)
IF /I "%shouldContinue%"=="Y" (
	GOTO SCRIPT_START
)
echo.
echo Wrong input. Please try again.
GOTO USER_CONSENT
echo.
:SCRIPT_START
%windir%\System32\reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection" /v latency /t REG_SZ /f /d "Demo" >NUL 2>&1

@echo off

echo.
echo Starting Microsoft Defender for Endpoint onboarding process...
echo.

set errorCode=0
set lastError=0
set "troubleshootInfo=For more information, visit: https://go.microsoft.com/fwlink/p/?linkid=822807"
set "errorDescription="

echo Testing administrator privileges

%windir%\System32\net.exe session >NUL 2>&1
if %ERRORLEVEL% NEQ 0 (
	@echo Script is running with insufficient privileges. Please run with administrator privileges> %WINDIR%\temp\senseTmp.txt
	set errorCode=65
 set lastError=%ERRORLEVEL%
	GOTO ERROR
)

echo Script is running with sufficient privileges
echo.
echo Performing onboarding operations
echo.

IF [%PROCESSOR_ARCHITEW6432%] EQU [] (
  set powershellPath=%windir%\System32\WindowsPowerShell\v1.0\powershell.exe
) ELSE (
  set powershellPath=%windir%\SysNative\WindowsPowerShell\v1.0\powershell.exe
)

set sdbin=0100048044000000540000000000000014000000020030000200000000001400FF0F120001010000000000051200000000001400E104120001010000000000050B0000000102000000000005200000002002000001020000000000052000000020020000 >NUL 2>&1
%windir%\System32\reg.exe add HKLM\SYSTEM\CurrentControlSet\Control\WMI\Security /v 14f8138e-3b61-580b-544b-2609378ae460 /t REG_BINARY /d %sdbin% /f >NUL 2>&1
%windir%\System32\reg.exe add HKLM\SYSTEM\CurrentControlSet\Control\WMI\Security /v cb2ff72d-d4e4-585d-33f9-f3a395c40be7 /t REG_BINARY /d %sdbin% /f >NUL 2>&1

%windir%\System32\reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v DisableEnterpriseAuthProxy /t REG_DWORD /f /d 1 >NUL 2>&1

%powershellPath% -ExecutionPolicy Bypass -NoProfile -Command "Add-Type ' using System; using System.IO; using System.Runtime.InteropServices; using Microsoft.Win32.SafeHandles; using System.ComponentModel; public static class Elam{ [DllImport(\"Kernel32\", CharSet=CharSet.Auto, SetLastError=true)] public static extern bool InstallELAMCertificateInfo(SafeFileHandle handle); public static void InstallWdBoot(string path) { Console.Out.WriteLine(\"About to call create file on {0}\", path); var stream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read); var handle = stream.SafeFileHandle; Console.Out.WriteLine(\"About to call InstallELAMCertificateInfo on handle {0}\", handle.DangerousGetHandle()); if (!InstallELAMCertificateInfo(handle)) { Console.Out.WriteLine(\"Call failed.\"); throw new Win32Exception(Marshal.GetLastWin32Error()); } Console.Out.WriteLine(\"Call successful.\"); } } '; $driverPath = $env:SystemRoot + '\System32\Drivers\WdBoot.sys'; [Elam]::InstallWdBoot($driverPath) " >NUL 2>&1

%windir%\System32\reg.exe query "HKLM\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection" /v 696C1FA1-4030-4FA4-8713-FAF9B2EA7C0A /reg:64 > %WINDIR%\temp\senseTmp.txt 2>&1
if %ERRORLEVEL% EQU 0 (  
    %windir%\System32\reg.exe delete "HKLM\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection" /v 696C1FA1-4030-4FA4-8713-FAF9B2EA7C0A /f > %WINDIR%\temp\senseTmp.txt 2>&1
    if %ERRORLEVEL% NEQ 0 (
        set "errorDescription=Unable to delete previous offboarding information from registry."
        set errorCode=5
        set lastError=%ERRORLEVEL%
        GOTO ERROR
    )
)

%windir%\System32\reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection" /v OnboardingInfo /t REG_SZ /f /d "{\"body\":\"{\\\"previousOrgIds\\\":[],\\\"orgId\\\":\\\"660e0bcb-202b-408e-801b-22ffd40a64c1\\\",\\\"geoLocationUrl\\\":\\\"https://winatp-gw-cus3.microsoft.com/\\\",\\\"datacenter\\\":\\\"CentralUs3\\\",\\\"vortexGeoLocation\\\":\\\"US\\\",\\\"version\\\":\\\"2.23\\\",\\\"packageGuid\\\":\\\"8693b1cc-2c89-47a4-a5f2-e41251cecd70\\\"}\",\"sig\":\"MMDdfMUh4yBY0GWKYPHJ65VoYNuqFBouKUdaKFy5MGZjpcKPSTYynLeFSdlm+puVxGppg7pGpaPuI/0jEDaNN35W4ZoiIn4FX38TQ10QSf1CBBK9ngpMjBZGBmCEFolP1+Q5L5+eqnipm1F5S0X7uPWe94660rwNqd4+3TbE/lnO6GNg9GvjSVFG9wlr53qUJuFw3phU/01JQr0jSQv7nMfe+GEPU5CdejosdSL2XVeW143S8KXyLuLslKJB3mVNA942OutlIGJsLg7BohVOGEs0upjpKnztgOut4pkKk0Hi3LZVIRdvn8rbzmASXOhuqu9s8giY1tfPOSCaCVq3xA==\",\"sha256sig\":\"MMDdfMUh4yBY0GWKYPHJ65VoYNuqFBouKUdaKFy5MGZjpcKPSTYynLeFSdlm+puVxGppg7pGpaPuI/0jEDaNN35W4ZoiIn4FX38TQ10QSf1CBBK9ngpMjBZGBmCEFolP1+Q5L5+eqnipm1F5S0X7uPWe94660rwNqd4+3TbE/lnO6GNg9GvjSVFG9wlr53qUJuFw3phU/01JQr0jSQv7nMfe+GEPU5CdejosdSL2XVeW143S8KXyLuLslKJB3mVNA942OutlIGJsLg7BohVOGEs0upjpKnztgOut4pkKk0Hi3LZVIRdvn8rbzmASXOhuqu9s8giY1tfPOSCaCVq3xA==\",\"cert\":\"MIIFkjCCA3qgAwIBAgITMwAABQ+jkgFBr/PGWgACAAAFDzANBgkqhkiG9w0BAQsFADB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgU2VjdXJlIFNlcnZlciBDQSAyMDExMB4XDTI2MDgyNzE4MTgwMVoXDTI3MDgyNzE4MTgwMVowJzElMCMGA1UEAxMcbTM2NWRvb3AtU2V2aWxsZS5XaW5kb3dzLmNvbTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAO8W9kT73Rx+6O+YK5wmFr3VCR6Q66+TPVfPUpOcW28Pp9fbDdabuwhnJ+1hrzRw4MTIxHxoFoAhS9blDjB1//HnMhkPdIZAemWGoZhVpMQlOB1k/jYRtWtNcXWRVgQzOsXjw/M6r3QE8AUFCH3Y8OGcaeB+wCN676TWBHmYCHaJqRztXHJBfNU5EZV3yoaHUcuzUsa/2t8vdbQOMBn/p7Xez01WSWdvY3HkVig95bAh8XOvDsaaH8GYt0t19OygdsElCa9zyCkVtJP7y1ZqJZ7CXhwEQBlcGC28B3BcymxeJY5Q5Tb10H6e6h1Ob493aeUkl9yf4lB1NOCs1b69qpkCAwEAAaOCAV4wggFaMA4GA1UdDwEB/wQEAwIFIDAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwDAYDVR0TAQH/BAIwADAeBgNVHREEFzAVghNTZXZpbGxlLldpbmRvd3MuY29tMB0GA1UdDgQWBBTqATCRTmEAjNUn0qK/e6NURrXDRzAfBgNVHSMEGDAWgBTI5pV+deRyVZao9Qv8nEJFwpcVhjBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNTZWNTZXJDQTIwMTFfMjAxMS0xMC0xOCgyKS5jcmwwYwYIKwYBBQUHAQEEVzBVMFMGCCsGAQUFBzAChkdodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY1NlY1NlckNBMjAxMV8yMDExLTEwLTE4KDIpLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAmSsCH2M9BCKBmWHlfivaj93VXAOPWLN7cq5Awca0DONLnErFtc1axs8jAxDt2VAPCXz3/4Z1vZHR9NgUJ1mOugOzf5r+Nv9JNUABLAErpkuvXv2GZxLHXhlGSXWGTGmNCjtjmYBVzam4K8I9GE14ZBNRyBM0NRKx2eEfOHmCZIWreFXG6BU9V11ss4pyMpVDqOI8k40VR5xBm72CoH4vb+JQhf5ow8QklxSHs15sMk9HS3V+5aBFAbaELyi+XZM3LiFR8CqnAXoYyud64K2XVOCKMSpQ3AnF2YRcV/IpWl/RXIWDwmXd9cSR36HjAUK4GntwLewgBrLlvCpfVBrMGk+efjmHUrHAbhYVHpjwiJgWdREOlyQfLev4vArKpfD+u3//fcsg/CMs0Hgd/O4b7NpptmzzfVW0W/j16IR4ziuuoeIIeyAE0cAb1TooMX6B0chTXb+50/6yXHJwrxYHQGF0lg2iX/ui67xV1xUGoafEm3oMV4HnI5zJj1PbOMAShOKvZ2UCQ0GiQVPiBGhSbsZGFVWgSlTI8MhPcR+M1w5HRoY/iBLP9JAO9RREb08D4mza9wzHMFcFpS1fgnZewl8agO8KltcF/RE/GMu0ysMpOWYAwbTfmPZXXat/ZJzL8KPymVgxw9a4A1ncSDkv0hNr+Tk35tiZlaEXnXXvEa8=\",\"chain\":[\"MIIHCzCCBPOgAwIBAgITMwAAAEbmBKqpBOkOywAAAAAARjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMjYwNzE0MTkyOTUyWhcNMjcxMDE0MTkyOTUyWjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgU2VjdXJlIFNlcnZlciBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApJtUl+kmhFm/UxIM7iTHks4+PT0VjFvhKfYRCOFx2tNvBaIFXbz8fWcGDPvTVPda5KKaLNwD6b29k6ZeptxuQnhJltD1VRw8DyrMNsRhcRkJFszdralvJEd8VJE78mQMBGSit9YNc1NYrU9eviuHXvwEcMaW3Zv2/5jMD4m4JUH/rYhX8yolzw3RzK3UHBQ4omZwtBAS7rZLsKmMuF246X8VPvLyojVjiQ8hH7xuxcoQAc2+w+rHVgP7wLWvP83RhTZ+NQttgf8viZkOZNL60Iz/G6Nx6T7jHrEjTFVDIXcKIS+0UjuehmMYnJg2Ae2jsVaZxPyw9pSnH1GZOCiarFsDhdeTjNrAtO+5GiceFa5tzmgrlg5Y0bZdBXFFLkfIqA+aBIDl8V9+d8OY8gxBe5uf5Pjzze/bQLFPdFTEIWu4jatO0vR+TQ4VYVnlGSq6TPwcyueiJqBd4X8wnKKIu/cjIEyCddTAu7rugl6cZKQ94Cv7Z92nrg3GKr6z8skO9iTsBzluiHN/uMV/z7DComU3IDXs+nXeTqbv6n6kfdne4w/1BWGRa6gk/2hSGYNO6fXUM+u/riz3MG2HXb7VKmDCTDxqzG0AAYLfikTIBqyUVdh40TvpgsIGGOy+UPdzRtPbF4UK4eFg0Kkssq9BE63iBnHM15omq2sssXYvQxMCAwEAAaOCAXUwggFxMA4GA1UdDwEB/wQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAgACMCMGCSsGAQQBgjcVAgQWBBT/V+ttgj6GtZgaHS50sG5xJx1T7DAdBgNVHQ4EFgQUyOaVfnXkclWWqPUL/JxCRcKXFYYwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQAUh7iviCToK5sRLSUzX/ueCHV3mxlKPVNt1Tn5OQ4QSPXRHu1ylAZmyq75UtZMl4uq/qzc9EXD+lvXooXmv4esX/QiNWhKG7QDILh8W77IT35j+tUiojGlFjfbN4Z+igj5fxEugKXaBXHSUArT/HkAJo6aJyWI4u9Ok7aSp8d1t1Wt789H+7F4Ofkcg2J/B3dq48COho46Q12bNf3wuAwkg7KdNykwmOqff+3Dm4v5fpRyoB9CccOytKrpoCP9BVywP03IpV6owqLNtljOFJvldHO0U63OIZTP4d3k0SyI5TH6PcffSfyyXaVoA2G+PlgJS4WfUh50Pj8PWC5N1oay7K3bc/t9nFGdMVC4yJkV4Qx16HFEp1D3QzoScpD6gIgbObXh/ElCJaMYI4a/ANlhKrI4UYRMmKGXbgdcIRtFzVvfQVlZlWTAP8sWAPCGVD/JjtgYlU3zdrx1RJ30HKjX5lKCKgN0B2m85ACeULqQHQiKV5x0Fmdy2zLdm3QPOwQMmz50gZnvBzQaPZ0HnG4mFXetOeVXNNRoP0i2nOv5u57oiYYWheXrz0masPVicBD240c1zd90c963HjVFq884rcnh0zza+d2rZzwAvcW65hZTzXsWb0e0GRDvBQX3tCGkVdzIbshsszbEGWD7yxRuByYaFo7cyfKLCi+5jgZjlg==\",\"MIIF7TCCA9WgAwIBAgIQP4vItfyfspZDtWnWbELhRDANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwMzIyMjIwNTI4WhcNMzYwMzIyMjIxMzA0WjCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCygEGqNThNE3IyaCJNuLLx/9VSvGzH9dJKjDbu0cJcfoyKrq8TKG/Ac+M6ztAlqFo6be+ouFmrEyNozQwph9FvgFyPRH9dkAFSWKxRxV8qh9zc2AodwQO5e7BW6KPeZGHCnvjzfLnsDbVU/ky2ZU+I8JxImQxCCwl8MVkXeQZ4KI2JOkwDJb5xalwL54RgpJki49KvhKSn+9GY7Qyp3pSJ4Q6g3MDOmT3qCFK7VnnkH4S6Hri0xElcTzFLh93dBWcmmYDgcRGjuKVB4qRTufcyKYMME782XgSzS0NHL2vikR7TmE/dQgfI6B0S/Jmpaz6SfsjWaTr8ZL22CZ3K/QwLopt3YEsDlKQwaRLWQi3BQUzK3Kr9j1uDRprZ/LHR47PJf0h6zSTwQY9cdNCssBAgBkm3xy0hyFfj0IbzA2j70M5xwYmZSmQBbP3sMJHPQTySx+W6hh1hhMdfgzlirrSSL0fzC/hV66AfWdC7dJse0Hbm8ukG1xDo+mTeacY1logC8Ea4PyeZb8txiSk190gWAjWP1Xl8TQLPX+uKg09FcYj5qQ1OcunCnAfPSRtOBA5jUYxe2ADBVSy2xuDCZU7JNDn1nLPEfuhhbhNfFcRf2X7tHc7uROzLLoax7Dj2cO2rXBPB2Q8Nx4CyVe0096yb5MPa50c8prWPMd/FS6/r8QIDAQABo1EwTzALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUci06AjGQQ7kUBU7h6qfHMdEjiTQwEAYJKwYBBAGCNxUBBAMCAQAwDQYJKoZIhvcNAQELBQADggIBAH9yzw+3xRXbm8BJyiZb/p4T5tPw0tuXX/JLP02zrhmu7deXoKzvqTqjwkGw5biRnhOBJAPmCf0/V0A5ISRW0RAvS0CpNoZLtFNXmvvxfomPEf4YbFGq6O0JlbXlccmh6Yd1phV/yX43VF50k8XDZ8wNT2uoFwxtCJJ+i92Bqi1wIcM9BhS7vyRep4TXPw8hIr1LAAbblxzYXtTFC1yHblCk6MM4pPvLLMWSZpuFXst6bJN8gClYW1e1QGm6CHmmZGIVnYeWRbVmIyADixxzoNOieTPgUFmG2y/lAiXqcyqfABTINseSO+lOAOzYVgm5M0kS0lQLAausR7aRKX1MtHWAUgHoyoL2n8ysnI8X6i8msKtyrAv+nlEex0NVZ09Rs1fWtuzuUrc66U7h14GIvE+OdbtLqPA1qibUZ2dJsnBMO5PcHd94kIZysjik0dySTclY6ysSXNQ7roxrsIPlAT/4CTL2kzU0Iq/dNw13CYArzUgA8YyZGUcFAenRv9FO0OYoQzeZpApKCNmacXPSqs0xE2N2oTdvkjgefRI8ZjLny23h/FKJ3crWZgWalmG+oijHHKOnNlA8OqTfSm7mhzvO6/DggTedEzxSjr25HTTGHdUKaj2YKXCMiSrRq4IQSB/c9O+lxbtVGjhjhE63bK2VVOxlIhBJF7jAHscPrFRH\"]}" > %WINDIR%\temp\senseTmp.txt 2>&1
if %ERRORLEVEL% NEQ 0 (
   set "errorDescription=Unable to write onboarding information to registry."
   set errorCode=10
   set lastError=%ERRORLEVEL%
   GOTO ERROR
)

echo Starting the service, if not already running
echo.
%windir%\System32\sc.exe query "SENSE" | %windir%\System32\find.exe /i "RUNNING" >NUL 2>&1
if %ERRORLEVEL% EQU 0 GOTO RUNNING

%windir%\System32\net.exe start sense > %WINDIR%\temp\senseTmp.txt 2>&1
if %ERRORLEVEL% NEQ 0 (
   echo Microsoft Defender for Endpoint Service has not started yet
   GOTO WAIT_FOR_THE_SERVICE_TO_START
)
goto SUCCEEDED

:RUNNING
set "runningOutput=The Microsoft Defender for Endpoint Service is already running!"
echo %runningOutput%
echo.
%windir%\System32\eventcreate.exe /l Application /so WDATPOnboarding /t Information /id 10 /d "%runningOutput%" >NUL 2>&1
GOTO WAIT_FOR_THE_SERVICE_TO_START

:ERROR
Set /P errorMsg=<%WINDIR%\temp\senseTmp.txt
set "errorOutput=[Error Id: %errorCode%, Error Level: %lastError%] %errorDescription% Error message: %errorMsg%"
%powershellPath% -ExecutionPolicy Bypass -NoProfile -Command "Add-Type 'using System; using System.Diagnostics; using System.Diagnostics.Tracing; namespace Sense { [EventData(Name = \"Onboarding\")]public struct Onboarding{public string Message { get; set; }} public class Trace {public static EventSourceOptions TelemetryCriticalOption = new EventSourceOptions(){Level = EventLevel.Error, Keywords = (EventKeywords)0x0000200000000000, Tags = (EventTags)0x0200000}; public void WriteOnboardingMessage(string message){es.Write(\"OnboardingScript\", TelemetryCriticalOption, new Onboarding {Message = message});} private static readonly string[] telemetryTraits = { \"ETW_GROUP\", \"{5ECB0BAC-B930-47F5-A8A4-E8253529EDB7}\" }; private EventSource es = new EventSource(\"Microsoft.Windows.Sense.Client.Management\",EventSourceSettings.EtwSelfDescribingEventFormat,telemetryTraits);}}'; $logger = New-Object -TypeName Sense.Trace; $logger.WriteOnboardingMessage('%errorOutput%')" >NUL 2>&1
echo %errorOutput%
echo %troubleshootInfo%
echo.
%windir%\System32\eventcreate.exe /l Application /so WDATPOnboarding /t Error /id %errorCode% /d "%errorOutput%" >NUL 2>&1
GOTO CLEANUP

:SUCCEEDED
echo Finished performing onboarding operations
echo.
GOTO WAIT_FOR_THE_SERVICE_TO_START

:WAIT_FOR_THE_SERVICE_TO_START
echo Waiting for the service to start
echo.

set /a counter=0

:SENSE_RUNNING_WAIT
%windir%\System32\sc.exe query "SENSE" | %windir%\System32\find.exe /i "RUNNING" >NUL 2>&1
if %ERRORLEVEL% NEQ 0 (
	IF %counter% EQU 4 (
		set "errorDescription=Unable to start Microsoft Defender for Endpoint Service."
		set errorCode=15
		set lastError=%ERRORLEVEL%
		GOTO ERROR
	)

	set /a counter=%counter%+1

	%windir%\System32\timeout.exe 5 >NUL 2>&1
	GOTO :SENSE_RUNNING_WAIT
)

set /a counter=0

:SENSE_ONBOARDED_STATUS_WAIT
%windir%\System32\reg.exe query "HKLM\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" /v OnboardingState /reg:64 >NUL 2>&1
if %ERRORLEVEL% NEQ 0 (
	IF %counter% EQU 4 (
		@echo Microsoft Defender for Endpoint Service is not running as expected> %WINDIR%\temp\senseTmp.txt
		set errorCode=35
     set lastError=%ERRORLEVEL%
		GOTO ERROR
	)

	set /a counter=%counter%+1

	%windir%\System32\timeout.exe 5 >NUL 2>&1
	GOTO :SENSE_ONBOARDED_STATUS_WAIT
)

set /a counter=0

:SENSE_ONBOARDED_WAIT
%windir%\System32\reg.exe query "HKLM\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" /v OnboardingState /reg:64 | %windir%\System32\find.exe /i "0x1" >NUL 2>&1
if %ERRORLEVEL% NEQ 0 (
	IF %counter% EQU 4 (
		@echo Microsoft Defender for Endpoint Service is not running as expected> %WINDIR%\temp\senseTmp.txt
		set errorCode=40
     set lastError=%ERRORLEVEL%
		GOTO ERROR
	)

	set /a counter=%counter%+1

	%windir%\System32\timeout.exe 5 >NUL 2>&1
	GOTO :SENSE_ONBOARDED_WAIT
)

set "successOutput=Successfully onboarded machine to Microsoft Defender for Endpoint"
echo %successOutput%
echo.
%windir%\System32\eventcreate.exe /l Application /so WDATPOnboarding /t Information /id 20 /d "%successOutput%" >NUL 2>&1
%powershellPath% -ExecutionPolicy Bypass -NoProfile -Command "Add-Type 'using System; using System.Diagnostics; using System.Diagnostics.Tracing; namespace Sense { [EventData(Name = \"Onboarding\")]public struct Onboarding{public string Message { get; set; }} public class Trace {public static EventSourceOptions TelemetryCriticalOption = new EventSourceOptions(){Level = EventLevel.Informational, Keywords = (EventKeywords)0x0000200000000000, Tags = (EventTags)0x0200000}; public void WriteOnboardingMessage(string message){es.Write(\"OnboardingScript\", TelemetryCriticalOption, new Onboarding {Message = message});} private static readonly string[] telemetryTraits = { \"ETW_GROUP\", \"{5ECB0BAC-B930-47F5-A8A4-E8253529EDB7}\" }; private EventSource es = new EventSource(\"Microsoft.Windows.Sense.Client.Management\",EventSourceSettings.EtwSelfDescribingEventFormat,telemetryTraits);}}'; $logger = New-Object -TypeName Sense.Trace; $logger.WriteOnboardingMessage('%successOutput%')" >NUL 2>&1
"%PROGRAMFILES%\Windows Defender\MpCmdRun.exe" -ReloadEngine >NUL 2>&1

GOTO CLEANUP

:CLEANUP
if exist %WINDIR%\temp\senseTmp.txt del %WINDIR%\temp\senseTmp.txt
pause
EXIT /B %errorCode%

